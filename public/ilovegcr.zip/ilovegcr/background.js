/**
 * Background Service Worker for Google Classroom Attachment Downloader
 * 
 * This script handles download requests from the content script.
 * It uses the Chrome Downloads API to save files locally.
 */

// Browser API compatibility
const browserAPI = typeof browser !== 'undefined' ? browser : chrome;

// =============================================================================
// MESSAGE LISTENER
// =============================================================================

/**
 * Listen for messages from content scripts
 */
browserAPI.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "DOWNLOAD_ATTACHMENTS") {
    console.log("[ilovegcr] Received download request for", message.attachments.length, "files");
    handleDownloadRequest(message.attachments, message.assignmentName)
      .then((results) => {
        console.log("[ilovegcr] Download request completed successfully");
        sendResponse({ success: true, results });
      })
      .catch((error) => {
        console.error("[ilovegcr] Download request failed:", error);
        console.error("[ilovegcr] Error stack:", error.stack);
        sendResponse({ success: false, error: error.message });
      });
    
    // Return true to indicate async response
    return true;
  } else if (message.action === "GET_DOWNLOAD_PATH") {
    getDownloadPath()
      .then((path) => {
        console.log("[ilovegcr] Retrieved download path:", path);
        sendResponse({ path });
      })
      .catch((error) => {
        console.error("[ilovegcr] Failed to get download path:", error);
        sendResponse({ path: "Downloads" });
      });
    return true;
  } else if (message.action === "SET_DOWNLOAD_PATH") {
    console.log("[ilovegcr] Setting download path to:", message.path);
    setDownloadPath(message.path)
      .then(() => sendResponse({ success: true }))
      .catch((error) => {
        console.error("[ilovegcr] Failed to set download path:", error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

// =============================================================================
// DOWNLOAD HANDLER
// =============================================================================

/**
 * Generate a timestamp string for unique folder naming
 * @returns {string} - Timestamp in format YYYY-MM-DD_HH-MM-SS
 */
function generateTimestamp() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day}_${hours}-${minutes}-${seconds}`;
}

/**
 * Process and download all attachments
 * @param {Array} attachments - Array of {url, filename} objects
 * @param {string} assignmentName - Name of the assignment for folder organization
 * @returns {Promise<Array>} - Results of download attempts
 */
async function handleDownloadRequest(attachments, assignmentName) {
  const results = [];
  const downloadPath = await getDownloadPath();
  const folderName = sanitizeFolderName(assignmentName || "Classroom_Downloads");
  const timestamp = generateTimestamp();
  const sessionFolder = `${folderName}_${timestamp}`;
  
  console.log(`[ilovegcr] Starting download of ${attachments.length} files`);
  console.log(`[ilovegcr] Saving to folder: ${downloadPath}/${sessionFolder}/`);
  
  for (const attachment of attachments) {
    try {
      const result = await downloadFile(attachment, sessionFolder);
      results.push({ url: attachment.url, success: true, downloadId: result });
      console.log(`[ilovegcr] Downloaded: ${attachment.filename}`);
    } catch (error) {
      results.push({ url: attachment.url, success: false, error: error.message });
      console.error(`[ilovegcr] Failed to download: ${attachment.filename}`, error);
    }
  }
  
  return results;
}

/**
 * Download a single file using fetch + blob approach
 * This ensures cookies are sent with the request
 * @param {Object} attachment - {url, filename} object
 * @param {string} folderName - Sanitized folder name
 * @returns {Promise<number>} - Download ID
 */
async function downloadFile(attachment, folderName) {
  const sanitizedFilename = sanitizeFilename(attachment.filename, attachment.url);
  const downloadPath = await getDownloadPath();
  const fullPath = `${downloadPath}/${folderName}/${sanitizedFilename}`;
  
  // Convert Google Drive/Docs URLs to direct download URLs
  const downloadUrl = convertToDownloadUrl(attachment.url);
  
  console.log(`[ilovegcr] Downloading to: ${fullPath}`);
  console.log(`[ilovegcr] From URL: ${downloadUrl}`);
  
  try {
    // First, try to fetch the file with credentials (cookies)
    const response = await fetch(downloadUrl, {
      credentials: 'include',
      redirect: 'follow'
    });
    
    if (!response.ok) {
      // If fetch fails, fall back to direct download (might prompt user)
      console.log(`[ilovegcr] Fetch returned ${response.status}, trying direct download...`);
      return await directDownload(downloadUrl, fullPath, sanitizedFilename);
    }
    
    // Convert response to blob
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);
    
    // Download the blob
    return new Promise((resolve, reject) => {
      browserAPI.downloads.download(
        {
          url: blobUrl,
          filename: fullPath,
          saveAs: false
        },
        (downloadId) => {
          // Clean up blob URL after a delay
          setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
          
          if (browserAPI.runtime.lastError) {
            console.error(`[ilovegcr] Download error: ${browserAPI.runtime.lastError.message}`);
            reject(new Error(browserAPI.runtime.lastError.message));
          } else if (downloadId === undefined) {
            reject(new Error("Download failed - check extension permissions"));
          } else {
            console.log(`[ilovegcr] Download started with ID: ${downloadId}`);
            resolve(downloadId);
          }
        }
      );
    });
  } catch (fetchError) {
    // CORS blocks fetch for Google Drive - this is expected, use direct download
    return await directDownload(downloadUrl, fullPath, sanitizedFilename);
  }
}

/**
 * Direct download fallback when fetch doesn't work
 */
function directDownload(downloadUrl, fullPath, sanitizedFilename) {
  return new Promise((resolve, reject) => {
    browserAPI.downloads.download(
      {
        url: downloadUrl,
        filename: fullPath,
        saveAs: false
      },
      (downloadId) => {
        if (browserAPI.runtime.lastError) {
          console.error(`[ilovegcr] Direct download error: ${browserAPI.runtime.lastError.message}`);
          reject(new Error(browserAPI.runtime.lastError.message));
        } else if (downloadId === undefined) {
          reject(new Error("Download failed - check extension permissions"));
        } else {
          console.log(`[ilovegcr] Direct download started with ID: ${downloadId}`);
          resolve(downloadId);
        }
      }
    );
  });
}

// =============================================================================
// URL CONVERSION UTILITIES
// =============================================================================

/**
 * Convert Google Drive/Docs URLs to direct download URLs
 * These URLs work with user's existing Google session
 * @param {string} url - Original URL
 * @returns {string} - Download-ready URL
 */
function convertToDownloadUrl(url) {
  // Google Drive file URL patterns
  // Pattern: https://drive.google.com/file/d/FILE_ID/view
  const driveFileMatch = url.match(/drive\.google\.com\/file\/d\/([^\/]+)/);
  if (driveFileMatch) {
    const fileId = driveFileMatch[1];
    // Use the usercontent domain which is more reliable for authenticated downloads
    return `https://drive.usercontent.google.com/download?id=${fileId}&export=download&confirm=t`;
  }
  
  // Google Drive open URL pattern
  // Pattern: https://drive.google.com/open?id=FILE_ID
  const driveOpenMatch = url.match(/drive\.google\.com\/open\?id=([^&]+)/);
  if (driveOpenMatch) {
    const fileId = driveOpenMatch[1];
    return `https://drive.usercontent.google.com/download?id=${fileId}&export=download&confirm=t`;
  }
  
  // Google Docs - export as docx
  // Pattern: https://docs.google.com/document/d/DOC_ID/...
  const docsMatch = url.match(/docs\.google\.com\/document\/d\/([^\/]+)/);
  if (docsMatch) {
    const docId = docsMatch[1];
    return `https://docs.google.com/document/d/${docId}/export?format=docx`;
  }
  
  // Google Sheets - export as xlsx
  // Pattern: https://docs.google.com/spreadsheets/d/SHEET_ID/...
  const sheetsMatch = url.match(/docs\.google\.com\/spreadsheets\/d\/([^\/]+)/);
  if (sheetsMatch) {
    const sheetId = sheetsMatch[1];
    return `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=xlsx`;
  }
  
  // Google Slides - export as pptx
  // Pattern: https://docs.google.com/presentation/d/SLIDES_ID/...
  const slidesMatch = url.match(/docs\.google\.com\/presentation\/d\/([^\/]+)/);
  if (slidesMatch) {
    const slidesId = slidesMatch[1];
    return `https://docs.google.com/presentation/d/${slidesId}/export/pptx`;
  }
  
  // Return original URL if no conversion needed (direct PDF links, etc.)
  return url;
}

// =============================================================================
// SANITIZATION UTILITIES
// =============================================================================

/**
 * Sanitize folder name for file system compatibility
 * @param {string} name - Original folder name
 * @returns {string} - Sanitized folder name
 */
function sanitizeFolderName(name) {
  if (!name || name.length === 0) {
    return "Classroom_Download";
  }
  
  return name
    .replace(/[<>:"/\\|?*]/g, " ")  // Replace invalid characters with space
    .replace(/\s+/g, " ")           // Normalize multiple spaces
    .trim()                          // Trim leading/trailing spaces
    .substring(0, 100)              // Limit length
    || "Classroom_Download";
}

/**
 * Sanitize filename for file system compatibility
 * @param {string} filename - Original filename
 * @param {string} url - The URL (to determine extension if needed)
 * @returns {string} - Sanitized filename
 */
function sanitizeFilename(filename, url = "") {
  // Check if filename already has an extension
  const hasExtension = /\.[a-zA-Z0-9]{2,5}$/.test(filename);
  
  // Extract extension if present
  let ext = "";
  let nameWithoutExt = filename;
  
  if (hasExtension) {
    const extMatch = filename.match(/\.([a-zA-Z0-9]+)$/);
    ext = extMatch ? extMatch[0] : "";
    nameWithoutExt = ext ? filename.slice(0, -ext.length) : filename;
  } else {
    // Add extension based on URL type
    if (url.includes("docs.google.com/document")) {
      ext = ".docx";
    } else if (url.includes("docs.google.com/spreadsheets")) {
      ext = ".xlsx";
    } else if (url.includes("docs.google.com/presentation")) {
      ext = ".pptx";
    } else if (url.includes("drive.google.com")) {
      // For Drive files, try to detect from filename or leave as is
      ext = "";
    }
  }
  
  const sanitizedName = nameWithoutExt
    .replace(/[<>:"/\\|?*]/g, "_")  // Replace invalid characters
    .replace(/\s+/g, " ")           // Normalize spaces (keep single spaces)
    .replace(/^[\s._]+|[\s._]+$/g, "") // Trim leading/trailing spaces, dots, underscores
    .substring(0, 200)              // Limit length
    || "unnamed_file";
  
  return sanitizedName + ext;
}

// =============================================================================
// STORAGE UTILITIES
// =============================================================================

/**
 * Get the current download path from storage
 * @returns {Promise<string>} - Download path
 */
function getDownloadPath() {
  return new Promise((resolve) => {
    browserAPI.storage.sync.get({ downloadPath: "Downloads" }, (result) => {
      resolve(result.downloadPath || "Downloads");
    });
  });
}

/**
 * Set the download path in storage
 * @param {string} path - New download path
 * @returns {Promise<void>}
 */
function setDownloadPath(path) {
  return new Promise((resolve) => {
    browserAPI.storage.sync.set({ downloadPath: path }, () => {
      console.log(`[ilovegcr] Download path updated to: ${path}`);
      resolve();
    });
  });
}

// =============================================================================
// INITIALIZATION
// =============================================================================

console.log("[Classroom Downloader] Background service worker initialized");
